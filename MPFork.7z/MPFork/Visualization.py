# -*- coding: utf-8 -*-
import numpy as np
import cv2
import os
def show_cam(pscore, img, name):
    cam = pscore#.cpu().detach().numpy()
#                    cam = np.maximum(cam, 0)
    cam = cam - np.min(cam)
    cam = cam / np.max(cam)
    #cam = cam.transpose((1, 2, 0))
    heatmap = cv2.applyColorMap(np.uint8(255 * cam), cv2.COLORMAP_JET)
    heatmap = np.float32(heatmap) / 255
    #img = img.squeeze().cpu().data.numpy()
    #img = img.transpose((1, 2, 0))
#                    img = np.float32(img)/255
    cam = heatmap + img
    cam = cam / np.max(cam)
    return cam

path = r'D:\abnormal_dataset\Shanghai_frames\Shanghai\testing\frames\12_0142\080.jpg' 
image = cv2.imread(path)        #image0 = Image.open(image)
image = image /255

k=85
#maps = ab_event3_pred[:,:,k]
maps = ab_event3[:,:,k]
maps = cv2.resize(maps, (856, 480), interpolation=cv2.INTER_CUBIC)  #ped2 (360, 240)  avenue (640, 360)  ,shanghai   (856, 480)
cam = show_cam(maps, image, k)
video_path = 'F:\\AED-data\\data_huizong\\Vis\\shanghai\\'
if not os.path.exists(video_path):
    os.makedirs(video_path)
cv2.imwrite(os.path.join(video_path, '12_0142_'+str(k) +'_Bipred.jpg'), np.uint8(255 * cam))
