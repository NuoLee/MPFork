import os
import sys
operating_system = sys.platform
#
#os.environ["CUDA_VISIBLE_DEVICES"] = "0, 1"
#
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"

if operating_system.find("win") == -1:
    os.environ["CUDA_VISIBLE_DEVICES"] = "1"
else:
    os.environ["CUDA_VISIBLE_DEVICES"] = "1"

'''
import args
os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"
if args.gpus is None:
    gpus = "0"
    os.environ["CUDA_VISIBLE_DEVICES"]= gpus
else:
    gpus = ""
    for i in range(len(args.gpus)):
        gpus = gpus + args.gpus[i] + ","
    os.environ["CUDA_VISIBLE_DEVICES"]= gpus[:-1]
'''
import args
import datetime
import tensorflow as tf

import utils
from utils import ProcessingType, create_dir
from object_extraction import *
import middle_consecutive.trainer as trainer
from compute_performance_scores import *

RUNNING_ID = str(datetime.datetime.now()).replace(" ", "_").replace(":", "-")
utils.set_vars(args.logs_folder, RUNNING_ID)
utils.create_dir(args.logs_folder)
args.log_parameters()

assert args.temporal_size == 15

'''
# extract the objects
extract_objects(ProcessingType.TRAIN, is_video=False)
# extract_objects(ProcessingType.TEST, is_video=False)

# resize objects for training
from resize_video_patches import *  
'''
trainer.train()

