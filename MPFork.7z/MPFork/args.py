#  2021, Anomaly Detection in Video via Self-Supervised and Multi-Task Learning
#  Mariana-Iuliana Georgescu, Antonio Barbalau, Radu Tudor Ionescu Fahad Shahbaz Khan, Marius Popescu, Mubarak Shah, CVPR
#  SecurifAI’s NonCommercial Use & No Sharing International Public License.

import numpy as np
import tensorflow as tf
import os
from utils import ProcessingType, log_message, check_file_existence
import pdb
import sys
from utils import create_dir

# operating_system = sys.platform
gpus = ['0']
tf_config = tf.compat.v1.ConfigProto()
#tf_config.gpu_options.per_process_gpu_memory_fraction = 0.48   #0.5
tf_config.gpu_options.allow_growth = True

temporal_size = 15  # when testing set to 3, training to 15
testresults = 'text_results'
temporal_offsets = np.arange(-temporal_size, temporal_size + 1, 1)
print('temporal_offsets', temporal_offsets)

t_len = 3
#
# detection_threshold = 0.5
# database_name = 'ped2'
# input_folder_base = 'D:/dataset/UCSD/ped2'
# lamda = 0.5
# block_scale = 3

# detection_threshold = 0.8 #avenue
# database_name = 'avenue'
# input_folder_base = 'D:/abnormal_dataset/avenue_dataset/avenue'
# lamda = 0.2
# block_scale = 20

detection_threshold = 0.8
database_name = 'Shanghai'
input_folder_base = 'D:/abnormal_dataset/Shanghai_frames/Shanghai'
lamda = 0.2
block_scale = 20



output_folder_base = 'F:\\AED-data'
samples_folder_name = 'images_%d_%.2f' % (temporal_size, detection_threshold)
samples_folder_name_context = 'images_with_context_%d_%.2f' % (temporal_size, detection_threshold)
optical_flow_folder_name = 'optical_flow_%d_%.2f' % (temporal_size, detection_threshold)
meta_folder_name = 'meta_%d_%.2f' % (temporal_size, detection_threshold)
imagenet_logits_folder_name = 'imagenet_logits_before_softmax'


def set_temporal_size(temporal_size_):
    global temporal_size
    temporal_size = temporal_size_



logs_folder = "logs"
num_samples_for_visualization = 500
CHECKPOINTS_PREFIX = 'conv3d'

CHECKPOINTS_BASE = os.path.join(output_folder_base, database_name, testresults, "checkpoints", CHECKPOINTS_PREFIX)
create_dir(CHECKPOINTS_BASE)

allowed_video_extensions = ['avi', 'mp4']
allowed_image_extensions = ['jpg', 'png', 'jpeg']
RESTORE_FROM_HISTORY = True

history_filename = "history_%s_%s.txt" % (database_name, '%s')

if RESTORE_FROM_HISTORY is False:
    print('removing history...')
    if check_file_existence(history_filename % ProcessingType.TRAIN.value):
        os.remove(history_filename % ProcessingType.TRAIN.value)
    if check_file_existence(history_filename % ProcessingType.TEST.value):
        os.remove(history_filename % ProcessingType.TEST.value)


def log_parameters():
    message = "\n" * 5 + "Starting the algorithm with the following parameters: \n"
    local_vars = globals()
    for v in local_vars.keys():
        if not v.startswith('_'):
            message += " " * 5 + v + "=" + str(local_vars[v]) + "\n"
    log_message(message)

