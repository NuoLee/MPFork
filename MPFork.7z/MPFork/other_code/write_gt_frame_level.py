import numpy as np
import os
import pdb
import scipy.io
import sys
sys.path.append("..")
from utils import get_file_name, ProcessingType
import args


# mat = scipy.io.loadmat('ped2.mat')
mat = scipy.io.loadmat('avenue.mat')
gt = mat['gt']
path = 'F:\AED-data\\avenue\\testing'
output_folder = os.path.join(path, "%s",
                             "ground_truth_frame_level.txt")

# video_names = ['%02d' % i for i in range(1, 13)]  #ped2
video_names = ['%02d' % i for i in range(1, 22)]  #avenue

for idx, file_name in enumerate(video_names):

    # take the num max of frames
    # video_dir = 'D:/dataset/UCSD/ped2/testing/frames/' + file_name # os.path.join(args.input_folder_base, ProcessingType.TEST.value, "frames", file_name)
    video_dir = 'D:/abnormal_dataset/avenue_dataset/avenue/testing/frames/' + file_name
    print(video_dir)
    video_names = [f for f in os.listdir(video_dir)]
    print(len(video_names))
    new_content = np.zeros((len(video_names)))

    for i in range(len(gt[0][idx][0])):
        start_anomaly = gt[0][idx][0][i] - 1
        end_anomaly = gt[0][idx][1][i]
        new_content[start_anomaly: end_anomaly] = 1
    np.savetxt(output_folder % file_name, new_content) 
    print(output_folder % file_name)

# meta_base_dir = os.path.join(args.output_folder_base, args.database_name, processing_type.value, "%s",
#                                  args.meta_folder_name, "%s")