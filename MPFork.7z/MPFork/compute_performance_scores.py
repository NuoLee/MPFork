import os
import numpy as np
import sklearn.cluster as sc
from sklearn.metrics import roc_curve, auc
import timeit
import pickle
import pdb
from scipy.ndimage import gaussian_filter1d
from scipy.ndimage import convolve
import math
import cv2 as cv
import random
import img_text
import img_text.model_img_text as model_img_text
import matplotlib.pyplot as plt

from utils import log_function_start, log_function_end, log_message, create_dir, ProcessingType, train_linear_svm,\
    check_file_existence
import args
#from test import save_message



def save_message_1(message):
    print(message)
    test_result_folder = os.path.join(args.output_folder_base, args.database_name, args.testresults, "test_result.txt")
    file_handler = open(test_result_folder, 'a')
    file_handler.write("\n" + "{}".format(message))
    file_handler.close()


def normalize_(err_):
    err_ = np.array(err_)
    err_ = err_ - min(err_)
    err_ = err_ / max(err_)
    return err_


def compute_anomaly_scores_per_object(processing_type: ProcessingType, save_per_video=True, epoch=None):
    log_function_start() 

    meta_base_dir = os.path.join(args.output_folder_base, args.database_name, processing_type.value, "%s",
                                 args.meta_folder_name, "%s")
    video_patch_base_dir = os.path.join(args.output_folder_base, args.database_name, processing_type.value,
                                        "%s", args.samples_folder_name, '%s')  # args.samples_folder_name

    videos_features_base_dir = os.path.join(args.output_folder_base, args.database_name, processing_type.value)

    videos_names = os.listdir(videos_features_base_dir)
    videos_names.sort()
    # concat_features_path = os.path.join(args.output_folder_base, args.database_name, processing_type.value, "%s",
    #                                     "anormality_scores.txt")
    # loc_v3_path = os.path.join(args.output_folder_base, args.database_name, processing_type.value, "%s",
    #                            "loc_v3.npy")
    #results_path = os.path.join(args.output_folder_base, args.database_name, args.testresults, "epoch_%02d" % epoch, "%s")
    concat_features_path = os.path.join(args.output_folder_base, args.database_name, args.testresults, "epoch_%02d" % epoch, "%s",
                                        "img_text_anormality_scores.txt")
    concat_features_path_cons = os.path.join(args.output_folder_base, args.database_name, args.testresults,
                                         "epoch_%02d" % epoch, "%s",
                                        "img_text_cons_scores.txt")
    concat_features_path_pred = os.path.join(args.output_folder_base, args.database_name, args.testresults,
                                         "epoch_%02d" % epoch, "%s",
                                        "img_text_pred_scores.txt")
    loc_v3_path = os.path.join(args.output_folder_base, args.database_name, args.testresults, "epoch_%02d" % epoch, "%s",
                               "loc_v3.npy")
    import torch
    import cv2
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model_img_text, preprocess = img_text.load("F:\AED-data\img_textmodel\ViT-B-32.pt", device=device)

    import middle_consecutive.trainer as trainer
    discriminator = trainer.Experiment(is_testing=True, checkpoint_epoch=epoch)

    all_features = []
    for video_name in videos_names:  # for each video
        # check if it is a dir
        if os.path.isdir(os.path.join(videos_features_base_dir, video_name)) is False:
            continue
        log_message(video_name)
        # read all the appearance features
        samples_names = os.listdir(meta_base_dir % (video_name, ""))  # maybe this is a hack :)
        samples_names.sort()
        if save_per_video:
            video_features_path = concat_features_path % video_name
            video_features_path_cons = concat_features_path_cons % video_name
            video_features_path_pred = concat_features_path_pred % video_name
            video_loc_v3_path = loc_v3_path % video_name

            results_path = os.path.join(args.output_folder_base, args.database_name, args.testresults,
                                        "epoch_%02d" % epoch, "%s")
            results_path = results_path % video_name
            create_dir(results_path)
            #create_dir(video_loc_v3_path)

        features_video = []
        errs_1 = []
        errs_2 = []
        loc_v3_video = []

        for sample_name in samples_names:
            try:
                video_patch = np.load(video_patch_base_dir % (video_name, sample_name.replace('.txt', '.npy'))) #image文件
                meta = np.loadtxt(meta_base_dir % (video_name, sample_name))
            except:
                log_message(sample_name)
                continue
            text_index = meta[5]
            Text = np.loadtxt("dictext.txt")
            text = Text[text_index]
            err_1, err_2 = discriminator.get_normality_score(video_patch, meta, text, model_img_text)  # pred, cons
            errs_1.append(err_1)
            errs_2.append(err_2)
            loc_v3_video.append(meta[:-2])

        # errs_1 = normalize_(errs_1)
        # errs_2 = normalize_(errs_2)
        # features_video = np.array(errs_1) + np.array(errs_2)

        features_video_cons = np.array(errs_2)
        features_video_pred = np.array(errs_1)
        if save_per_video:
            np.savetxt(video_features_path, features_video)
            np.savetxt(video_features_path_cons, features_video_cons)
            np.savetxt(video_features_path_pred, features_video_pred)
            np.save(video_loc_v3_path, loc_v3_video)

    # save the features
    if not save_per_video:
        np.save(concat_features_path, all_features)
    log_function_end()


def gaussian_filter_3d(sigma=1.0):
    x = np.array([-2, -1, 0, 1, 2])
    f = np.exp(- (x ** 2) / (2 * (sigma ** 2))) / (sigma * np.sqrt(2 * np.pi)) #5
    f += (1 - np.sum(f)) / len(f)
    k = np.expand_dims(f, axis=1).T * np.expand_dims(f, axis=1)  #5*5
    k3d = np.expand_dims(k, axis=2).T * np.expand_dims(np.expand_dims(f, axis=1), axis=2) #5*5*5
    # k3d = k3d * 3
    return k3d


def gaussian_filter_(support, sigma):
    mu = support[len(support) // 2 - 1]
    filter = 1.0 / (sigma * np.sqrt(2 * math.pi)) * np.exp(-0.5 * ((support - mu) / sigma) ** 2)
    return filter


def predict_anomaly_on_frames(video_info_path, result_path, filter_3d, filter_2d):
    video_normality_scores = np.loadtxt(os.path.join(result_path, "img_text_pred_scores.txt"))  #anormality_scores.txt resnet_scores
    # video_normality_scores1 = np.loadtxt(os.path.join(result_path, "img_text_cons_scores.txt"))
    # video_normality_scores = video_normality_scores1 + video_normality_scores
    video_loc_v3 = np.load(os.path.join(result_path, "loc_v3.npy"))

    video_meta_data = pickle.load(open(os.path.join(video_info_path, "video_meta_data.pkl"), 'rb'))
    video_height = video_meta_data["height"]
    video_width = video_meta_data["width"]

    block_scale = args.block_scale
    block_h = int(round(video_height / block_scale)) #360/20
    block_w = int(round(video_width / block_scale)) #640/20

    anomaly_scores = video_normality_scores - min(video_normality_scores) #6745
    anomaly_scores = anomaly_scores / max(anomaly_scores)

    num_frames = video_meta_data["num_frames"]
    num_bboxes = len(anomaly_scores)

    ab_event = np.zeros((block_h, block_w, num_frames))
    for i in range(num_bboxes):
        loc_V3 = np.int32(video_loc_v3[i])

        ab_event[int(round(loc_V3[2] / block_scale)): int(round(loc_V3[4] / block_scale)) + 1,
        int(round(loc_V3[1] / block_scale)): int(round(loc_V3[3] / block_scale) + 1), loc_V3[0]] = np.maximum(
            ab_event[int(round(loc_V3[2] / block_scale)):int(round(loc_V3[4] / block_scale)) + 1,
            int(round(loc_V3[1] / block_scale)): int(round(loc_V3[3] / block_scale)) + 1,
            loc_V3[0]], anomaly_scores[i])
    

    dim = 9
    filter_3d = np.ones((dim, dim, dim)) / (dim ** 3)
    ab_event3 = convolve(ab_event, filter_3d)  #  ab_event.copy() #(18,32,1439)
    np.save(os.path.join(result_path, 'ab_event3_pred.npy'), ab_event3)
    frame_scores = np.zeros(num_frames)
    for i in range(num_frames):
        frame_scores[i] = ab_event3[:, :, i].max()

    # padding_size = len(filter_2d) // 2
    # # np.savetxt('anomaly_on_frames/' + video_info_path.split(os.sep)[-1] + '.txt', frame_scores)
    # # in_ = np.concatenate((np.zeros(padding_size), frame_scores, np.zeros(padding_size)))  #avenue,shanghai
    # in_ = np.concatenate((frame_scores[:padding_size], frame_scores, frame_scores[-padding_size:])) #ped2
    # frame_scores = np.correlate(in_, filter_2d, 'valid')
    return frame_scores


def compute_performance_indices(processing_type:ProcessingType=ProcessingType.TEST, epoch=None):
    log_function_start()
    filter_3d = gaussian_filter_3d(sigma=25)
    filter_2d = gaussian_filter_(np.arange(1, 50), 20)  #ped2
    # filter_2d = gaussian_filter_(np.arange(1, 302), 25)  # avenue
    # filter_2d = gaussian_filter_(np.arange(1, 202), 31)  # shanghaitech

    # list all the testing videos
    videos_features_base_dir = os.path.join(args.output_folder_base, args.database_name, processing_type.value)
    testing_videos_names =[name for name in os.listdir(videos_features_base_dir) if os.path.isdir(os.path.join(videos_features_base_dir, name))]
    testing_videos_names.sort()
    all_frame_scores = []
    all_gt_frame_scores = []
    roc_auc_videos = []
    
    for video_name in testing_videos_names:
        #log_message(video_name)
        result_path = os.path.join(args.output_folder_base, args.database_name, args.testresults, "epoch_%02d" % epoch, video_name)
        video_scores = predict_anomaly_on_frames(os.path.join(videos_features_base_dir, video_name), result_path, filter_3d, filter_2d)
        all_frame_scores = np.append(all_frame_scores, video_scores)
        # read the ground truth scores at frame level
        gt_scores = np.loadtxt(os.path.join(videos_features_base_dir, video_name, "ground_truth_frame_level.txt"))
        # label_base_dir = os.path.join(args.output_folder_base, args.database_name)
        # gt_scores = np.load(os.path.join(label_base_dir, "test_frame_mask", "%s.npy" % video_name))   # shanghai
        all_gt_frame_scores = np.append(all_gt_frame_scores, gt_scores)
        fpr, tpr, _ = roc_curve(np.concatenate(([0], gt_scores, [1])), np.concatenate(([0], video_scores, [1])))
        roc_auc = auc(fpr, tpr)
        save_message_1("{} - {}".format(video_name, roc_auc))
        #print(roc_auc)
        roc_auc_videos.append(roc_auc)

    # plt.plot(all_gt_frame_scores)
    # plt.plot(all_frame_scores)
    # plt.show()
    anomalyscore_dir = os.path.join(args.output_folder_base, args.database_name, args.testresults, "epoch_%02d" % epoch)
    np.save(os.path.join(anomalyscore_dir, "gt.npy"), all_gt_frame_scores)
    np.save(os.path.join(anomalyscore_dir, "img_text_framescore_pred_nofilter.npy"), all_frame_scores)
    fpr, tpr, _ = roc_curve(all_gt_frame_scores, all_frame_scores)
    roc_auc = auc(fpr, tpr)
    save_message_1("Frame-based AUC is %.3f on %s (all data set)." % (roc_auc, args.database_name))
    save_message_1("Avg. (on video) frame-based AUC is %.3f on %s." % (np.array(roc_auc_videos).mean(), args.database_name))
    log_function_end()

