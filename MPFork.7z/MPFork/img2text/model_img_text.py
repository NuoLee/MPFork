import numpy as np
import tensorflow as tf
import os
from utils import ProcessingType, log_message, check_file_existence
import pdb
import sys
from utils import create_dir

# operating_system = sys.platform
gpus = ['0']
tf_config = tf.compat.v1.ConfigProto()
#tf_config.gpu_options.per_process_gpu_memory_fraction = 0.48   #0.5
tf_config.gpu_options.allow_growth = True



num_samples_for_visualization = 500

allowed_video_extensions = ['avi', 'mp4']
allowed_image_extensions = ['jpg', 'png', 'jpeg']
RESTORE_FROM_HISTORY = True
#img-text


def log_parameters():
    message = "\n" * 5 + "Starting the algorithm with the following parameters: \n"
    local_vars = globals()
    for v in local_vars.keys():
        if not v.startswith('_'):
            message += " " * 5 + v + "=" + str(local_vars[v]) + "\n"
    log_message(message)


