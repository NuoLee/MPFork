import os
import args
# import sys
# #os.environ["CUDA_VISIBLE_DEVICES"] = "1"
# operating_system = sys.platform
#
# os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
#
# if operating_system.find("win") == -1:
#     os.environ["CUDA_VISIBLE_DEVICES"] = '1'
# else:
#     os.environ["CUDA_VISIBLE_DEVICES"] = '1'

os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"
if args.gpus is None:
    gpus = "0"
    os.environ["CUDA_VISIBLE_DEVICES"]= gpus
else:
    gpus = ""
    for i in range(len(args.gpus)):
        gpus = gpus + args.gpus[i] + ","
    os.environ["CUDA_VISIBLE_DEVICES"]= gpus[:-1]

from compute_performance_scores import compute_performance_indices, compute_anomaly_scores_per_object
from utils import ProcessingType, create_dir
import utils
import datetime
import args
from object_extraction import *

# do not delete this
RUNNING_ID = str(datetime.datetime.now()).replace(" ", "_").replace(":", "-")
utils.set_vars(args.logs_folder, RUNNING_ID)
utils.create_dir(args.logs_folder)
args.log_parameters()

def save_message(message):

    print(message)
    test_result_folder = os.path.join(args.output_folder_base, args.database_name, args.testresults, "test_result.txt")
    #create_dir(test_result_folder)
    if not os.path.exists(test_result_folder):
        f = open(test_result_folder, 'w')
        f.close()
    file_handler = open(test_result_folder, 'a')
    #file_handler = open(os.path.join(test_result_folder, '%s_log.txt' % RUNNING_ID), 'a')
    file_handler.write("\n" + "{}".format(message))
    file_handler.close()

extract_objects(ProcessingType.TEST, is_video=False)

assert args.temporal_size == 5
testlist = [28]
for i in testlist:
    save_message("Epoch is %2d:********************************************************" % i)
    compute_anomaly_scores_per_object(ProcessingType.TEST, epoch=i)   #(ProcessingType.TEST, epoch=i)
    compute_performance_indices(ProcessingType.TEST, epoch=i)
